const STRING = {
    // Local Storage //

    TOKEN:"Token",
    USER:"User",
    }

    export default STRING;