export {default as COLORS } from './colors';
export {default as IMAGES } from './images';
// export {ProfileDetails,dashboardIconItems,Gender,MarriedStatus} from './array';
export {default as STRING } from './strings';
export { FS, LH, FF } from './fonts';