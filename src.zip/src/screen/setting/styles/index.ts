export { default as SettingStyles } from './settingStyles';
export { default as HelpStyles } from './helpStyles';
export { default as ProfileSettingStyles } from './profileSettingStyles';