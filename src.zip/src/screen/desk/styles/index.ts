export { default as DeskStyles } from './deskStyles';
