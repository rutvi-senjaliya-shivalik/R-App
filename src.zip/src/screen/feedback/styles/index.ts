export { default as FeedbackStyles} from './feedbackStyle';

