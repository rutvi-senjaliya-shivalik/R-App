// import React, { useEffect, useState } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   TextInput,
//   ScrollView,
//   KeyboardAvoidingView,
//   TouchableWithoutFeedback,
//   Keyboard,
//   Platform,
//   Alert,
// } from 'react-native';
// import DatePicker from 'react-native-date-picker';
// import { useNavigation } from '@react-navigation/native';
// import { Container, HeaderComponent } from '../../components/common';
// import { useDispatch } from 'react-redux';
// import { applyleaveAction } from './Actions/ApplyleaveAction';
// import { leavetypelistAction } from './Actions/LeavetypeList';
// import PrefManager from '../../utils/prefManager';

// interface LeaveType {
//   id: string;
//   name: string;
//   balance: number;
// }

// type Session = 'Full Day' | 'Half Day';

// const ApplyLeave: React.FC = (props: any) => {
//   const dispatch = useDispatch() as any;
//   const navigation = useNavigation();

//   const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);
//   const [selectedLeave, setSelectedLeave] = useState<LeaveType | null>(null);
//   const [showLeaveList, setShowLeaveList] = useState(false);
//   const [loadingLeaveTypes, setLoadingLeaveTypes] = useState(false);
//   const [fromDate, setFromDate] = useState<Date | null>(null);
//   const [toDate, setToDate] = useState<Date | null>(null);
//   const [pickerMode, setPickerMode] = useState<'from' | 'to' | null>(null);
//   const [showPicker, setShowPicker] = useState(false);
//   const [fromSession, setFromSession] = useState<Session>('Full Day');
//   const [toSession, setToSession] = useState<Session>('Full Day');
//   const [contact, setContact] = useState<string>('');
//   const [reason, setReason] = useState<string>('');
//   const [attachment, setAttachment] = useState<string | null>(null);
//   const [loadingSubmit, setLoadingSubmit] = useState<boolean>(false);

//   const openDatePicker = (mode: 'from' | 'to') => {
//     setPickerMode(mode);
//     setShowPicker(true);
//   };

//   const handleAttach = () => {
//     setAttachment('Leave_Doc.pdf');
//   };

//   const handleSubmit = async () => {
//     if (
//       !selectedLeave ||
//       !fromDate ||
//       (!toDate && fromSession === 'Full Day') ||
//       !contact ||
//       !reason
//     ) {
//       Alert.alert('Please fill all fields before submitting.');
//       return;
//     }

//     try {
//       setLoadingSubmit(true);

//       // Determine the to_date based on session
//       const toDateValue =
//         fromSession === 'Half Day'
//           ? fromDate // same date for half-day
//           : toDate; // normal to date for full day

//       // Prepare payload
//       const payload = {
//         leave_type_id: selectedLeave.id,
//         leave_taken: fromSession === 'Full Day' ? 'Full Day' : 'Half Day',
//         from_date: fromDate?.toISOString().split('T')[0] || '',
//         to_date: toDateValue?.toISOString().split('T')[0] || '',
//         reason,
//         contact,
//         attachment,
//       };

//       const response = await dispatch(applyleaveAction(payload));

//       if (response?.status == '200') {
//         Alert.alert('Leave applied successfully!');
//         // Call Holiday List API after successful submission
//         await ApicallGetHolidaylist(
//           (fromDate || new Date()).getFullYear().toString(),
//         );
//         navigation.goBack();
//       } else {
//         Alert.alert('Error', response?.message || 'Something went wrong!');
//       }
//     } catch (error) {
//       console.log('🚨 Exception occurred:', error);
//       Alert.alert('Error', 'Failed to apply leave. Please try again.');
//     } finally {
//       setLoadingSubmit(false);
//     }
//   };

//   const formatDate = (date: Date | null): string =>
//     date ? date.toLocaleDateString('en-GB') : 'Select Date';

//   const dismissKeyboard = () => Keyboard.dismiss();

//   useEffect(() => {
//     ApicallGetLeavetypelist();
//   }, []);

//   const ApicallGetLeavetypelist = async (): Promise<void> => {
//     try {
//       setLoadingLeaveTypes(true);

//       const userData = await PrefManager.getValue('userData');
//       const userId = JSON.parse(userData)._id;

//       const payload = { id: userId };
//       const response = await dispatch(leavetypelistAction(payload));

//       if (response?.status === 200) {
//         const types = response.data.message.map((item: any) => ({
//           id: item.leave_type_id,
//           name: item.name,
//         }));
//         setLeaveTypes(types);
//       } else {
//         console.log(
//           '🚨 API Error:',
//           response?.data?.message || 'Unknown error',
//         );
//       }
//     } catch (error: any) {
//       console.log('🚨 Exception occurred:', error);
//     } finally {
//       setLoadingLeaveTypes(false);
//     }
//   };

//   // ✅ Holiday List API
//   const ApicallGetHolidaylist = async (year: string) => {
//     try {
//       const payload = { year };
//       const response = await dispatch(applyleaveAction(payload));

//       if (response?.status == '200') {
//         console.log('Holiday List:', response.data);
//       } else {
//         console.log('🚨 API Error:', response?.message || 'Unknown error');
//       }
//     } catch (error) {
//       console.log('🚨 Exception occurred:', error);
//     }
//   };

//   // Automatically clear To Date if From Session is Half Day
//   useEffect(() => {
//     if (fromSession === 'Half Day') setToDate(null);
//   }, [fromSession]);

//   return (
//     <Container>
//       <HeaderComponent
//         onPress={() => props.navigation.goBack()}
//         Title="Apply Leave"
//       />

//       <KeyboardAvoidingView
//         behavior={Platform.OS === 'ios' ? 'padding' : undefined}
//         style={{ flex: 1 }}
//       >
//         <TouchableWithoutFeedback onPress={dismissKeyboard}>
//           <ScrollView
//             showsVerticalScrollIndicator={false}
//             keyboardShouldPersistTaps="handled"
//             contentContainerStyle={styles.scrollContent}
//           >
//             <View style={styles.formContainer}>
//               {/* Leave Type */}
//               <Text style={styles.label}>Select Leave Type</Text>
//               <TouchableOpacity
//                 style={[
//                   styles.dropdown,
//                   {
//                     justifyContent: 'space-between',
//                     flexDirection: 'row',
//                     alignItems: 'center',
//                   },
//                 ]}
//                 onPress={() => setShowLeaveList(prev => !prev)}
//               >
//                 <Text style={styles.dropdownText}>
//                   {selectedLeave ? selectedLeave.name : 'Select Leave Type'}
//                 </Text>
//                 <Text style={styles.dropdownText}>
//                   {showLeaveList ? '▲' : '▼'}
//                 </Text>
//               </TouchableOpacity>

//               {showLeaveList && !loadingLeaveTypes && (
//                 <View style={[styles.dropdown, { marginTop: 4 }]}>
//                   {leaveTypes.map(type => (
//                     <TouchableOpacity
//                       key={type.id}
//                       style={[
//                         styles.dropdownItem,
//                         selectedLeave?.id === type.id && styles.selectedItem,
//                       ]}
//                       onPress={() => {
//                         setSelectedLeave(type);
//                         setShowLeaveList(false);
//                       }}
//                     >
//                       <Text style={styles.dropdownText}>{type.name}</Text>
//                     </TouchableOpacity>
//                   ))}
//                 </View>
//               )}

//               {/* From Date */}
//               <Text style={styles.label}>From Date</Text>
//               <View style={styles.row}>
//                 <TouchableOpacity
//                   style={styles.dateButton}
//                   onPress={() => openDatePicker('from')}
//                 >
//                   <Text style={styles.dateText}>{formatDate(fromDate)}</Text>
//                 </TouchableOpacity>
//                 <TouchableOpacity
//                   style={styles.sessionButton}
//                   onPress={() =>
//                     setFromSession(prev =>
//                       prev === 'Full Day' ? 'Half Day' : 'Full Day',
//                     )
//                   }
//                 >
//                   <Text style={styles.sessionText}>{fromSession}</Text>
//                 </TouchableOpacity>
//               </View>

//               {/* To Date */}
//               {fromSession === 'Full Day' && (
//                 <>
//                   <Text style={styles.label}>To Date</Text>
//                   <View style={styles.row}>
//                     <TouchableOpacity
//                       style={styles.dateButton}
//                       onPress={() => openDatePicker('to')}
//                     >
//                       <Text style={styles.dateText}>{formatDate(toDate)}</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity
//                       style={styles.sessionButton}
//                       onPress={() =>
//                         setToSession(prev =>
//                           prev === 'Full Day' ? 'Half Day' : 'Full Day',
//                         )
//                       }
//                     >
//                       <Text style={styles.sessionText}>{toSession}</Text>
//                     </TouchableOpacity>
//                   </View>
//                 </>
//               )}

//               {/* Contact */}
//               <Text style={styles.label}>Contact Details</Text>
//               <TextInput
//                 style={styles.input}
//                 placeholder="Enter your contact number"
//                 keyboardType="phone-pad"
//                 value={contact}
//                 onChangeText={setContact}
//               />

//               {/* Reason */}
//               <Text style={styles.label}>Reason</Text>
//               <TextInput
//                 style={[styles.input, { height: 80 }]}
//                 multiline
//                 placeholder="Enter reason for leave"
//                 value={reason}
//                 onChangeText={setReason}
//               />

//               {/* Attachment */}
//               <Text style={styles.label}>Attachment</Text>
//               <TouchableOpacity
//                 style={styles.attachButton}
//                 onPress={handleAttach}
//               >
//                 <Text style={styles.attachText}>
//                   {attachment ? attachment : 'Upload File'}
//                 </Text>
//               </TouchableOpacity>

//               {/* Submit */}
//               <TouchableOpacity
//                 style={styles.submitButton}
//                 onPress={handleSubmit}
//                 disabled={loadingSubmit}
//               >
//                 <Text style={styles.submitText}>
//                   {loadingSubmit ? 'Applying...' : 'Apply'}
//                 </Text>
//               </TouchableOpacity>
//             </View>
//           </ScrollView>
//         </TouchableWithoutFeedback>
//       </KeyboardAvoidingView>

//       <DatePicker
//         modal
//         open={showPicker}
//         date={
//           pickerMode === 'from' ? fromDate || new Date() : toDate || new Date()
//         }
//         mode="date"
//         onConfirm={date => {
//           if (pickerMode === 'from') setFromDate(date);
//           else setToDate(date);
//           setShowPicker(false);
//         }}
//         onCancel={() => setShowPicker(false)}
//       />
//     </Container>
//   );
// };

// export default ApplyLeave;

// const styles = StyleSheet.create({
//   scrollContent: { flexGrow: 1 },
//   formContainer: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 30 },
//   label: {
//     fontSize: 14,
//     fontWeight: '500',
//     color: '#444',
//     marginTop: 14,
//     marginBottom: 6,
//   },
//   dropdown: {
//     backgroundColor: '#FFF',
//     borderRadius: 8,
//     borderWidth: 1,
//     borderColor: '#DDD',
//     paddingHorizontal: 12,
//   },
//   dropdownItem: { paddingVertical: 1 },
//   selectedItem: {},
//   dropdownText: {
//     fontSize: 15,
//     color: '#222',
//     marginVertical: 13,
//     marginLeft: 10,
//   },
//   row: { flexDirection: 'row', justifyContent: 'space-between' },
//   dateButton: {
//     flex: 0.6,
//     borderWidth: 1,
//     borderColor: '#DDD',
//     borderRadius: 8,
//     paddingVertical: 12,
//     alignItems: 'center',
//   },
//   dateText: { fontSize: 14, color: '#111' },
//   sessionButton: {
//     flex: 0.35,
//     borderWidth: 1,
//     borderColor: '#DDD',
//     borderRadius: 8,
//     paddingVertical: 12,
//     alignItems: 'center',
//   },
//   sessionText: { fontSize: 14, color: '#111' },
//   input: {
//     borderWidth: 1,
//     borderColor: '#DDD',
//     borderRadius: 8,
//     padding: 12,
//     backgroundColor: '#FFF',
//     fontSize: 14,
//     color: '#000',
//   },
//   attachButton: {
//     borderWidth: 1,
//     borderColor: '#DDD',
//     borderRadius: 8,
//     padding: 14,
//     backgroundColor: '#FFF',
//     alignItems: 'center',
//   },
//   attachText: { fontSize: 14, color: '#000' },
//   submitButton: {
//     backgroundColor: '#000',
//     borderRadius: 10,
//     paddingVertical: 14,
//     alignItems: 'center',
//     marginTop: 30,
//   },
//   submitText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
// });
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  Platform,
  Alert,
} from 'react-native';
import DatePicker from 'react-native-date-picker';
import { useNavigation } from '@react-navigation/native';
import { Container, HeaderComponent } from '../../components/common';
import { useDispatch } from 'react-redux';
import { applyleaveAction } from './Actions/ApplyleaveAction';
import { leavetypelistAction } from './Actions/LeavetypeList';
import PrefManager from '../../utils/prefManager';

interface LeaveType {
  id: string;
  name: string;
  balance: number;
}

type Session = 'Full Day' | 'Half Day';

const ApplyLeave: React.FC = (props: any) => {
  const dispatch = useDispatch() as any;
  const navigation = useNavigation();

  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);
  const [selectedLeave, setSelectedLeave] = useState<LeaveType | null>(null);
  const [showLeaveList, setShowLeaveList] = useState(false);
  const [loadingLeaveTypes, setLoadingLeaveTypes] = useState(false);
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);
  const [pickerMode, setPickerMode] = useState<'from' | 'to' | null>(null);
  const [showPicker, setShowPicker] = useState(false);
  const [fromSession, setFromSession] = useState<Session>('Full Day');
  const [toSession, setToSession] = useState<Session>('Full Day');
  const [reason, setReason] = useState<string>('');
  const [loadingSubmit, setLoadingSubmit] = useState<boolean>(false);

  const openDatePicker = (mode: 'from' | 'to') => {
    setPickerMode(mode);
    setShowPicker(true);
  };

  const handleSubmit = async () => {
    if (
      !selectedLeave ||
      !fromDate ||
      (!toDate && fromSession === 'Full Day') ||
      !reason
    ) {
      Alert.alert('Please fill all fields before submitting.');
      return;
    }

    try {
      setLoadingSubmit(true);

      // Determine the to_date based on session
      const toDateValue = fromSession === 'Half Day' ? fromDate : toDate;

      // Prepare payload
      const payload = {
        leave_type_id: selectedLeave.id,
        leave_taken: fromSession === 'Full Day' ? 'Full Day' : 'Half Day',
        from_date: fromDate?.toISOString().split('T')[0] || '',
        to_date: toDateValue?.toISOString().split('T')[0] || '',
        reason,
      };

      const response = await dispatch(applyleaveAction(payload));

      if (response?.status == '200') {
        Alert.alert('Leave applied successfully!');
        await ApicallGetHolidaylist(
          (fromDate || new Date()).getFullYear().toString(),
        );
        navigation.goBack();
      } else {
        Alert.alert('Error', response?.message || 'Something went wrong!');
      }
    } catch (error) {
      console.log('🚨 Exception occurred:', error);
      Alert.alert('Error', 'Failed to apply leave. Please try again.');
    } finally {
      setLoadingSubmit(false);
    }
  };

  const formatDate = (date: Date | null): string =>
    date ? date.toLocaleDateString('en-GB') : 'Select Date';

  const dismissKeyboard = () => Keyboard.dismiss();

  useEffect(() => {
    ApicallGetLeavetypelist();
  }, []);

  const ApicallGetLeavetypelist = async (): Promise<void> => {
    try {
      setLoadingLeaveTypes(true);
      const userData = await PrefManager.getValue('userData');
      const userId = JSON.parse(userData)._id;

      const payload = { id: userId };
      const response = await dispatch(leavetypelistAction(payload));
      console.log();

      if (response?.status === 200) {
        const types = response.data.message.map((item: any) => ({
          id: item.leave_type_id,
          name: item.name,
        }));
        setLeaveTypes(types);
      } else {
        console.log(
          '🚨 API Error:',
          response?.data?.message || 'Unknown error',
        );
      }
    } catch (error: any) {
      console.log('🚨 Exception occurred:', error);
    } finally {
      setLoadingLeaveTypes(false);
    }
  };

  const ApicallGetHolidaylist = async (year: string) => {
    try {
      const payload = { year };
      const response = await dispatch(applyleaveAction(payload));

      if (response?.status == '200') {
        console.log('Holiday List:', response.data);
      } else {
        console.log('🚨 API Error:', response?.message || 'Unknown error');
      }
    } catch (error) {
      console.log('🚨 Exception occurred:', error);
    }
  };

  // Automatically clear To Date if From Session is Half Day
  useEffect(() => {
    if (fromSession === 'Half Day') setToDate(null);
  }, [fromSession]);

  return (
    <Container>
      <HeaderComponent
        onPress={() => props.navigation.goBack()}
        Title="Apply Leave"
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
      >
        <TouchableWithoutFeedback onPress={dismissKeyboard}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scrollContent}
          >
            <View style={styles.formContainer}>
              {/* Leave Type */}
              <Text style={styles.label}>Select Leave Type</Text>
              <TouchableOpacity
                style={[
                  styles.dropdown,
                  {
                    justifyContent: 'space-between',
                    flexDirection: 'row',
                    alignItems: 'center',
                  },
                ]}
                onPress={() => setShowLeaveList(prev => !prev)}
              >
                <Text style={styles.dropdownText}>
                  {selectedLeave ? selectedLeave.name : 'Select Leave Type'}
                </Text>
                <Text style={styles.dropdownText}>
                  {showLeaveList ? '▲' : '▼'}
                </Text>
              </TouchableOpacity>

              {showLeaveList && !loadingLeaveTypes && (
                <View style={[styles.dropdown, { marginTop: 4 }]}>
                  {leaveTypes.map(type => (
                    <TouchableOpacity
                      key={type.id}
                      style={[
                        styles.dropdownItem,
                        selectedLeave?.id === type.id && styles.selectedItem,
                      ]}
                      onPress={() => {
                        setSelectedLeave(type);
                        setShowLeaveList(false);
                      }}
                    >
                      <Text style={styles.dropdownText}>{type.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

              {/* From Date */}
              <Text style={styles.label}>From Date</Text>
              <View style={styles.row}>
                <TouchableOpacity
                  style={styles.dateButton}
                  onPress={() => openDatePicker('from')}
                >
                  <Text style={styles.dateText}>{formatDate(fromDate)}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.sessionButton}
                  onPress={() =>
                    setFromSession(prev =>
                      prev === 'Full Day' ? 'Half Day' : 'Full Day',
                    )
                  }
                >
                  <Text style={styles.sessionText}>{fromSession}</Text>
                </TouchableOpacity>
              </View>

              {/* To Date */}
              {fromSession === 'Full Day' && (
                <>
                  <Text style={styles.label}>To Date</Text>
                  <View style={styles.row}>
                    <TouchableOpacity
                      style={styles.dateButton}
                      onPress={() => openDatePicker('to')}
                    >
                      <Text style={styles.dateText}>{formatDate(toDate)}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.sessionButton}
                      onPress={() =>
                        setToSession(prev =>
                          prev === 'Full Day' ? 'Half Day' : 'Full Day',
                        )
                      }
                    >
                      <Text style={styles.sessionText}>{toSession}</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}

              {/* Reason */}
              <Text style={styles.label}>Reason</Text>
              <TextInput
                style={[styles.input, { height: 80 }]}
                multiline
                placeholder="Enter reason for leave"
                value={reason}
                onChangeText={setReason}
              />

              {/* Submit */}
              <TouchableOpacity
                style={styles.submitButton}
                onPress={handleSubmit}
                disabled={loadingSubmit}
              >
                <Text style={styles.submitText}>
                  {loadingSubmit ? 'Applying...' : 'Apply'}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>

      <DatePicker
        modal
        open={showPicker}
        date={
          pickerMode === 'from' ? fromDate || new Date() : toDate || new Date()
        }
        mode="date"
        onConfirm={date => {
          if (pickerMode === 'from') setFromDate(date);
          else setToDate(date);
          setShowPicker(false);
        }}
        onCancel={() => setShowPicker(false)}
      />
    </Container>
  );
};

export default ApplyLeave;

const styles = StyleSheet.create({
  scrollContent: { flexGrow: 1 },
  formContainer: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 30 },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#444',
    marginTop: 14,
    marginBottom: 6,
  },
  dropdown: {
    backgroundColor: '#FFF',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD',
    paddingHorizontal: 12,
  },
  dropdownItem: { paddingVertical: 1 },
  selectedItem: {},
  dropdownText: {
    fontSize: 15,
    color: '#222',
    marginVertical: 13,
    marginLeft: 10,
  },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  dateButton: {
    flex: 0.6,
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  dateText: { fontSize: 14, color: '#111' },
  sessionButton: {
    flex: 0.35,
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  sessionText: { fontSize: 14, color: '#111' },
  input: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#FFF',
    fontSize: 14,
    color: '#000',
  },
  attachButton: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 14,
    backgroundColor: '#FFF',
    alignItems: 'center',
  },
  attachText: { fontSize: 14, color: '#000' },
  submitButton: {
    backgroundColor: '#000',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 30,
  },
  submitText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
});
