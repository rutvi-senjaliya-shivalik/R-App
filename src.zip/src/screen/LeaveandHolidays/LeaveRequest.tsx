import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { Container, HeaderComponent } from '../../components/common';

// --- Static Leave Request Data ---
const initialLeaveRequests = [
  {
    id: '1',
    type: 'Casual Leave',
    fromDate: '2025-01-10',
    toDate: '2025-01-10',
    applier: 'Rahul Sharma',
    contact: '+91 9876543210',
    reason: 'Family function out of town',
    attachment: true,
    halfDay: '2025-01-10',
  },
  {
    id: '2',
    type: 'Sick Leave',
    fromDate: '2025-02-05',
    toDate: '2025-02-07',
    applier: 'Priya Mehta',
    contact: '+91 9988776655',
    reason: 'Fever and rest recommended by doctor',
    attachment: false,
  },
  {
    id: '3',
    type: 'Earned Leave',
    fromDate: '2025-03-20',
    toDate: '2025-03-20',
    applier: 'Ankit Patel',
    contact: '+91 9123456789',
    reason: 'Vacation trip with family',
    attachment: true,
    halfDay: '2025-03-25',
  },
];

const LeaveRequest = (props: any) => {
  const [requests, setRequests] = useState(initialLeaveRequests);
  const [rejectModal, setRejectModal] = useState(false);
  const [selectedId, setSelectedId] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const inputRef = useRef<TextInput>(null);

  // ✅ Approve Leave - remove from list
  const handleApprove = (id: string) => {
    Alert.alert('Leave Approved', `Request ID: ${id}`);
    setRequests(prev => prev.filter(req => req.id !== id));
  };

  // ✅ Reject Leave - open modal & auto focus input
  const handleReject = (id: string) => {
    setSelectedId(id);
    setRejectModal(true);
    setTimeout(() => inputRef.current?.focus(), 300);
  };

  // ✅ Confirm Rejection
  const confirmReject = () => {
    if (!rejectReason.trim()) {
      Alert.alert('Please enter a reason for rejection.');
      return;
    }
    Alert.alert('Leave Rejected', `Reason: ${rejectReason}`);
    setRequests(prev => prev.filter(req => req.id !== selectedId));
    setRejectModal(false);
    setRejectReason('');
  };

  // ✅ Helper: format date properly
  const renderDateRange = (item: any) => {
    const { fromDate, toDate, halfDay } = item;

    // same date case
    if (fromDate === toDate) {
      const dateLabel = halfDay === fromDate ? `${fromDate} (Half)` : fromDate;
      return dateLabel;
    }

    // range case
    const fromLabel = halfDay === fromDate ? `${fromDate} (Half)` : fromDate;
    const toLabel = halfDay === toDate ? `${toDate} (Half)` : toDate;
    return `${fromLabel} → ${toLabel}`;
  };

  return (
    <Container>
      <HeaderComponent
        onPress={() => props.navigation.goBack()}
        Title="Leave Requests"
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        style={styles.scrollContainer}
        contentContainerStyle={styles.contentContainer}
      >
        {requests.length === 0 ? (
          <Text style={styles.emptyText}>No pending leave requests 🎉</Text>
        ) : (
          requests.map(item => (
            <View key={item.id} style={styles.card}>
              <View style={styles.rowBetween}>
                <Text style={styles.leaveType}>{item.type}</Text>
                <Text style={styles.dates}>{renderDateRange(item)}</Text>
              </View>

              <View style={styles.separator} />

              <View style={styles.detailRow}>
                <Text style={styles.label}>Applier:</Text>
                <Text style={styles.value}>{item.applier}</Text>
              </View>

              <View style={styles.detailRow}>
                <Text style={styles.label}>Contact:</Text>
                <Text style={styles.value}>{item.contact}</Text>
              </View>

              <View style={styles.detailRow}>
                <Text style={styles.label}>Reason:</Text>
                <Text style={styles.value}>{item.reason}</Text>
              </View>

              {item.attachment && (
                <TouchableOpacity style={styles.attachmentButton}>
                  <Text style={styles.attachmentText}>📎 View Attachment</Text>
                </TouchableOpacity>
              )}

              <View style={styles.actionRow}>
                <TouchableOpacity
                  style={[styles.btn, styles.approveBtn]}
                  onPress={() => handleApprove(item.id)}
                >
                  <Text style={styles.btnText}>Approve</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.btn, styles.rejectBtn]}
                  onPress={() => handleReject(item.id)}
                >
                  <Text style={styles.btnText}>Reject</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      {/* Reject Modal */}
      <Modal
        visible={rejectModal}
        transparent
        animationType="fade"
        onRequestClose={() => setRejectModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Reject Leave</Text>
            <TextInput
              ref={inputRef}
              placeholder="Enter reason for rejection"
              placeholderTextColor="#999"
              value={rejectReason}
              onChangeText={setRejectReason}
              multiline
              style={styles.input}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalBtn, { backgroundColor: '#E0E0E0' }]}
                onPress={() => setRejectModal(false)}
              >
                <Text style={[styles.modalBtnText, { color: '#333' }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, { backgroundColor: '#E53935' }]}
                onPress={confirmReject}
              >
                <Text style={styles.modalBtnText}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </Container>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 30,
  },
  card: {
    backgroundColor: '#F8F8F8',
    borderRadius: 14,
    padding: 16,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  leaveType: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  dates: {
    fontSize: 13,
    color: '#555',
  },
  separator: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 10,
  },
  detailRow: {
    flexDirection: 'row',
    marginVertical: 3,
  },
  label: {
    fontSize: 14,
    color: '#555',
    width: 90,
    fontWeight: '500',
  },
  value: {
    flex: 1,
    fontSize: 14,
    color: '#000',
  },
  attachmentButton: {
    marginTop: 10,
    alignSelf: 'flex-start',
    backgroundColor: '#EAEAEA',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
  },
  attachmentText: {
    fontSize: 13,
    color: '#000',
  },
  actionRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 12,
  },
  btn: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginLeft: 10,
  },
  approveBtn: {
    backgroundColor: '#4CAF50',
  },
  rejectBtn: {
    backgroundColor: '#E53935',
  },
  btnText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 13.5,
  },
  emptyText: {
    textAlign: 'center',
    color: '#555',
    marginTop: 40,
    fontSize: 15,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    paddingHorizontal: 24,
    bottom: 80,
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 18,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 8,
    padding: 10,
    minHeight: 80,
    color: '#000',
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 12,
  },
  modalBtn: {
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginLeft: 10,
  },
  modalBtnText: {
    color: '#FFF',
    fontWeight: '600',
  },
});

export default LeaveRequest;
