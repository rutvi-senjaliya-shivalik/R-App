export {default as Loginstyles} from './loginstyles';
export {default as LandingStyles} from './landingStyles';
export {default as OtpScreenStyles} from './otpScreenStyles';
export {default as ProfileStyles} from './profileStyles';
export {default as WhoAmIStyles} from './whoAmIStyles';
export {default as TerritoryStyles} from './territoryStyles';