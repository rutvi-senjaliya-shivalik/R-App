export interface HeaderComponentProps {
    Title: string;
    onPress:any
  }